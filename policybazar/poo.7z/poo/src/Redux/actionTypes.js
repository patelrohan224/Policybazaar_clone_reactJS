export const ADD_PLAN="add_plans"
export const GET_PLANS="get_plans"
export const SET_PLAN="set_plan"
export const SET_INFO="set_info"